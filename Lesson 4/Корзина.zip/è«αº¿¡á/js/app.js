'use strict';


var FOOD = ['Абрикос', 'Анис', 'Авокадо', 'Ананас', 'Бекон', 'Груша', 'Зайчатина', 'Индейка', 'Карамбола', 'Киви'];

var getFoods = function () {
	let weight = [];
	let price = [];
	
	for (let i = 0; i < 20; i++) {
		weight.push((Math.trunc(Math.random () * 100) / 100) * 4  + ' кг.' );
	}
	
	for (let i = 0; i < 300 ; i++) {
		price.push(Math.floor (Math.random()* 400 + (Math.random() * 44)) + 'руб.')
	}

	let food = [];
	
	for (let i = 0; i < 20; i++) {
		let NewFood = {
			food : FOOD[Math.floor(Math.random () * FOOD.length)],
			weight : weight[Math.floor(Math.random () * weight.length)],
			price : price[Math.floor(Math.random() * price.length)],
		};
		food.push(NewFood);
	}
	return food;
};

var loadFoods = function () {
	let loadedContent = getFoods();

	let fragment = document.createDocumentFragment();

	for (let i = 0; i < 100; i++) {
		let newParagraph = document.createElement('p');

		newParagraph.innerHTML = i + 1 + '. <b>' + loadedContent[i].food + '</b> / ' + loadedContent[i].weight + ' / ' + loadedContent[i].price;
		fragment.appendChild(newParagraph);
		};
		document.querySelector('.list').appendChild(fragment);
}

window.addEventListener('load', loadFoods);
		
